package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class LeftBishop extends Bishop
{
    public LeftBishop(Color color)
    {
        super(color);
    }
}
