package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class RightBishop extends Bishop
{
    public RightBishop(Color color)
    {
        super(color);
    }
}
