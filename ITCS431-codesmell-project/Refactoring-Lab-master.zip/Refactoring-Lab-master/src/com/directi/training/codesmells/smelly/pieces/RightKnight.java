package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class RightKnight extends Knight
{
    public RightKnight(Color color)
    {
        super(color);
    }
}
