package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class RightRook extends Rook
{
    public RightRook(Color color)
    {
        super(color);
    }
}
