package com.directi.training.codesmells.smelly.pieces;

import com.directi.training.codesmells.smelly.Color;

public class LeftKnight extends Knight
{
    public LeftKnight(Color color)
    {
        super(color);
    }
}
